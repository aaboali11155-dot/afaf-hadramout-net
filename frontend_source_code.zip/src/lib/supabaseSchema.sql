-- جداول مشروع عفاف حضرموت نت
-- قم بتشغيل هذا الملف في محرر SQL الخاص بـ Supabase

-- 1. جدول المستخدمين (يرتبط بـ auth.users)
create table if not exists public.users (
  id uuid references auth.users on delete cascade primary key,
  email text unique not null,
  gender text not null check (gender in ('male', 'female')),
  role text not null default 'user' check (role in ('user', 'admin')),
  is_active boolean not null default true,
  accepted_oath boolean not null default false,
  created_at timestamp with time zone default now()
);

-- 2. جدول الملفات الشخصية
create table if not exists public.profiles (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.users(id) on delete cascade unique not null,
  name text not null,
  age integer not null check (age >= 18),
  gender text not null check (gender in ('male', 'female')),
  city text not null,
  social_status text not null,
  education text not null,
  occupation text not null,
  height integer,
  skin_color text,
  origin text,
  religious_level text,
  about_me text,
  partner_specs jsonb default '{}'::jsonb,
  is_approved boolean not null default false,
  is_visible boolean not null default true,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- 3. جدول الرسائل
create table if not exists public.messages (
  id uuid default gen_random_uuid() primary key,
  sender_id uuid references public.users(id) on delete cascade not null,
  receiver_id uuid references public.users(id) on delete cascade not null,
  content text not null,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  admin_note text,
  created_at timestamp with time zone default now()
);

-- السياسات الأمنية الأساسية
alter table public.users enable row level security;
alter table public.profiles enable row level security;
alter table public.messages enable row level security;

-- المستخدمون
CREATE POLICY "Users can read own user" ON public.users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Admins can read all users" ON public.users
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Users can insert own user" ON public.users
  FOR INSERT WITH CHECK (auth.uid() = id);

CREATE POLICY "Admins can update users" ON public.users
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- الملفات الشخصية
CREATE POLICY "Profiles are readable by public if approved and visible" ON public.profiles
  FOR SELECT USING (is_approved = true AND is_visible = true);

CREATE POLICY "Users can read own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can read all profiles" ON public.profiles
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Admins can update profiles" ON public.profiles
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- الرسائل
CREATE POLICY "Users can read own messages" ON public.messages
  FOR SELECT USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Admins can read all messages" ON public.messages
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

CREATE POLICY "Users can send messages" ON public.messages
  FOR INSERT WITH CHECK (auth.uid() = sender_id);

CREATE POLICY "Admins can update messages" ON public.messages
  FOR UPDATE USING (
    EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin')
  );

-- دالة لإنشاء المستخدم تلقائياً عند التسجيل
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.users (id, email, gender, role, accepted_oath)
  values (new.id, new.email, 'male', 'user', false);
  return new;
end;
$$ language plpgsql security definer;

create or replace trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
