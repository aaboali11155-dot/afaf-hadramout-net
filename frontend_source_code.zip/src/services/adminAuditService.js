import { supabase } from '../lib/supabase';

export async function fetchAdminAuditLog() {
  const { data, error } = await supabase
    .from('admin_audit_log')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(200);

  if (error) throw error;
  return data;
}

export async function logAdminAction({ action, entityType, entityId, details = '' }) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from('admin_audit_log')
    .insert({
      admin_user_id: user.id,
      action,
      entity_type: entityType,
      entity_id: entityId,
      details,
    })
    .select()
    .single();

  if (error) {
    // لا نوقف العملية الرئيسية إذا فشل السجل
    console.warn('Audit log failed:', error.message);
    return null;
  }
  return data;
}
