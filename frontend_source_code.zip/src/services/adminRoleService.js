import { supabase } from '../lib/supabase';

export async function setUserAdminRole(userId, { isAdmin, adminRole = null }) {
  const { data, error } = await supabase
    .from('profiles')
    .update({
      is_admin: isAdmin,
      admin_role: adminRole,
      account_status: 'active',
    })
    .eq('user_id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function revokeAdmin(userId) {
  return setUserAdminRole(userId, { isAdmin: false, adminRole: null });
}

export async function makeAdmin(userId, adminRole = 'moderator') {
  return setUserAdminRole(userId, { isAdmin: true, adminRole });
}
