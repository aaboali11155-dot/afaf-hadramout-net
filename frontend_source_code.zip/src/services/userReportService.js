import { supabase } from '../lib/supabase';

export async function submitUserReport({ reportedUserId, reason, details = '' }) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('يجب تسجيل الدخول');

  const { data, error } = await supabase
    .from('reports')
    .insert({
      reporter_user_id: user.id,
      reported_user_id: reportedUserId,
      reason,
      details,
      status: 'open',
    })
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function fetchAllUserReports() {
  const { data, error } = await supabase
    .from('reports')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

export async function updateUserReport(id, updates) {
  const { data, error } = await supabase
    .from('reports')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function resolveUserReport(id) {
  return updateUserReport(id, { status: 'resolved' });
}

export async function dismissUserReport(id) {
  return updateUserReport(id, { status: 'dismissed' });
}
