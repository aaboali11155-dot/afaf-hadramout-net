import { supabase } from '../lib/supabase';

export async function fetchUserMessages(userId) {
  const { data, error } = await supabase
    .from('messages')
    .select('*')
    .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

export async function fetchAllMessages() {
  const { data, error } = await supabase
    .from('messages')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

export async function sendMessage(message) {
  const { data, error } = await supabase.from('messages').insert(message).select().single();
  if (error) throw error;
  return data;
}

export async function approveMessage(id) {
  const { data, error } = await supabase
    .from('messages')
    .update({ status: 'approved' })
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function rejectMessage(id) {
  const { data, error } = await supabase
    .from('messages')
    .update({ status: 'rejected' })
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
}
