import { supabase } from '../lib/supabase';

export async function fetchMyContactRequests() {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('يجب تسجيل الدخول');

  const { data, error } = await supabase
    .from('contact_requests')
    .select('*')
    .or(`sender_user_id.eq.${user.id},receiver_user_id.eq.${user.id}`)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

export async function fetchAllContactRequests() {
  const { data, error } = await supabase
    .from('contact_requests')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

export async function sendContactRequest(request) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('يجب تسجيل الدخول');

  const { data, error } = await supabase
    .from('contact_requests')
    .insert({ ...request, sender_user_id: user.id, status: 'pending' })
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function updateContactRequest(id, updates) {
  const { data, error } = await supabase
    .from('contact_requests')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function approveContactRequest(id) {
  return updateContactRequest(id, { status: 'approved' });
}

export async function rejectContactRequest(id) {
  return updateContactRequest(id, { status: 'rejected' });
}
