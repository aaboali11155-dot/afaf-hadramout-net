import { supabase } from '../lib/supabase';

const PUBLIC_PROFILE_COLUMNS = `
  id,
  الاسم,
  العمر,
  الجنس,
  المدينة,
  الحالة_الاجتماعية,
  المؤهل_الدراسي,
  الوظيفة,
  الطول,
  لون_البشرة,
  قبلي_او_حضري,
  نبذة_عن_نفسه,
  is_admin,
  admin_role,
  account_status
`;

export async function fetchApprovedProfiles() {
  const { data, error } = await supabase
    .from('profiles')
    .select(PUBLIC_PROFILE_COLUMNS)
    .eq('account_status', 'active')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

export async function fetchProfileByUserId(userId) {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('user_id', userId)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  return data || null;
}

export async function fetchProfileById(id) {
  const { data, error } = await supabase
    .from('profiles')
    .select(PUBLIC_PROFILE_COLUMNS)
    .eq('id', id)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  return data || null;
}

export async function fetchMyProfile(userId) {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('user_id', userId)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  return data || null;
}

export async function fetchAllProfiles() {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

export async function createProfile(profile) {
  const { data, error } = await supabase.from('profiles').insert(profile).select().single();
  if (error) throw error;
  return data;
}

export async function updateProfile(id, updates) {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function approveProfile(id) {
  return updateProfile(id, { account_status: 'active' });
}

export async function hideProfile(id) {
  return updateProfile(id, { account_status: 'hidden' });
}

export async function toggleProfileVisibility(id, isVisible) {
  return updateProfile(id, { account_status: isVisible ? 'active' : 'hidden' });
}

export async function suspendProfile(id) {
  return updateProfile(id, { account_status: 'suspended' });
}

export async function recordProfileView(visitorUserId, visitedProfileId) {
  const { error } = await supabase.from('profile_views').insert({
    visitor_user_id: visitorUserId,
    visited_profile_id: visitedProfileId,
  });
  if (error) throw error;
}

export async function fetchMyProfileViews(profileId) {
  const { data, error } = await supabase
    .from('profile_views')
    .select(`
      id,
      created_at,
      visitor_user_id,
      visitor:profiles!profile_views_visitor_user_id_fkey(id,الاسم,العمر,المدينة,الحالة_الاجتماعية,account_status)
    `)
    .eq('visited_profile_id', profileId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
}
