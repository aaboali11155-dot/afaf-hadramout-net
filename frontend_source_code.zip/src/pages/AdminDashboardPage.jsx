import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  FileText,
  MessageSquare,
  Shield,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Ban,
  Unlock,
  Eye,
  EyeOff,
  Flag,
  ScrollText,
} from 'lucide-react';
import {
  getEducationLabel,
  getSocialLabel,
  getReligiousLabel,
} from '../data/mockData';
import { fetchAllProfiles, updateProfile } from '../services/profileService';
import { fetchAllContactRequests, updateContactRequest } from '../services/contactRequestService';
import { fetchAllSiteIssues, updateSiteIssue } from '../services/siteIssueService';
import { fetchAllUserReports, updateUserReport } from '../services/userReportService';
import { makeAdmin, revokeAdmin } from '../services/adminRoleService';
import { fetchAllUserBlocks, unblockUser } from '../services/adminBlockService';
import { fetchAdminAuditLog } from '../services/adminAuditService';

export default function AdminDashboardPage({ currentUser }) {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('profiles');
  const [profiles, setProfiles] = useState([]);
  const [requests, setRequests] = useState([]);
  const [issues, setIssues] = useState([]);
  const [reports, setReports] = useState([]);
  const [blocks, setBlocks] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!currentUser?.isAdmin) return;
    async function loadData() {
      try {
        const [p, r, i, rep, b, a] = await Promise.all([
          fetchAllProfiles(),
          fetchAllContactRequests(),
          fetchAllSiteIssues(),
          fetchAllUserReports(),
          fetchAllUserBlocks(),
          fetchAdminAuditLog(),
        ]);
        setProfiles(p || []);
        setRequests(r || []);
        setIssues(i || []);
        setReports(rep || []);
        setBlocks(b || []);
        setAuditLogs(a || []);
      } catch (err) {
        setError(err.message || 'تعذر تحميل بيانات لوحة التحكم');
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [currentUser?.isAdmin]);

  if (!currentUser || !currentUser.isAdmin) {
    return (
      <div className="mx-auto max-w-md py-16 text-center">
        <div className="card">
          <Shield className="mx-auto mb-4 h-12 w-12 text-red-500" />
          <h2 className="mb-3 text-xl font-bold text-gray-900">وصول مرفوض</h2>
          <p className="mb-6 text-gray-600">هذه الصفحة مخصصة للمشرفين فقط.</p>
          <button onClick={() => navigate('/')} className="btn-primary w-full">
            العودة للرئيسية
          </button>
        </div>
      </div>
    );
  }

  const stats = {
    totalUsers: profiles.length,
    pendingProfiles: profiles.filter((p) => p.account_status === 'pending').length,
    pendingMessages: requests.filter((m) => m.status === 'pending').length,
    approvedProfiles: profiles.filter((p) => p.account_status === 'active').length,
    openIssues: issues.filter((i) => i.status === 'open').length,
    openReports: reports.filter((r) => r.status === 'open').length,
  };

  const handleApproveProfile = async (profileId) => {
    try {
      await updateProfile(profileId, { account_status: 'active' });
      setProfiles((prev) => prev.map((p) => (p.id === profileId ? { ...p, account_status: 'active' } : p)));
    } catch (err) {
      setError(err.message || 'تعذر تحديث حالة الملف');
    }
  };

  const handleToggleVisibility = async (profileId) => {
    const profile = profiles.find((p) => p.id === profileId);
    const nextStatus = profile?.account_status === 'active' ? 'hidden' : 'active';
    try {
      await toggleProfileVisibility(profileId, nextStatus === 'active');
      setProfiles((prev) => prev.map((p) => (p.id === profileId ? { ...p, account_status: nextStatus } : p)));
    } catch (err) {
      setError(err.message || 'تعذر تحديث رؤية الملف');
    }
  };

  const handleSuspendProfile = async (profileId) => {
    try {
      await updateProfile(profileId, { account_status: 'suspended' });
      setProfiles((prev) => prev.map((p) => (p.id === profileId ? { ...p, account_status: 'suspended' } : p)));
    } catch (err) {
      setError(err.message || 'تعذر تعليق الملف');
    }
  };

  const handleReviewRequest = async (requestId, status) => {
    try {
      await updateContactRequest(requestId, { status });
      setRequests((prev) => prev.map((r) => (r.id === requestId ? { ...r, status } : r)));
    } catch (err) {
      setError(err.message || 'تعذر تحديث حالة الطلب');
    }
  };

  const handleReviewIssue = async (issueId, status) => {
    try {
      await updateSiteIssue(issueId, { status });
      setIssues((prev) => prev.map((i) => (i.id === issueId ? { ...i, status } : i)));
    } catch (err) {
      setError(err.message || 'تعذر تحديث حالة البلاغ');
    }
  };

  const handleReviewReport = async (reportId, status) => {
    try {
      await updateUserReport(reportId, { status });
      setReports((prev) => prev.map((r) => (r.id === reportId ? { ...r, status } : r)));
    } catch (err) {
      setError(err.message || 'تعذر تحديث حالة البلاغ');
    }
  };

  const handleMakeAdmin = async (userId, role) => {
    try {
      const updated = await makeAdmin(userId, role);
      setProfiles((prev) => prev.map((p) => (p.user_id === userId ? { ...p, is_admin: updated.is_admin, admin_role: updated.admin_role } : p)));
    } catch (err) {
      setError(err.message || 'تعذر ترقية المستخدم');
    }
  };

  const handleRevokeAdmin = async (userId) => {
    try {
      const updated = await revokeAdmin(userId);
      setProfiles((prev) => prev.map((p) => (p.user_id === userId ? { ...p, is_admin: updated.is_admin, admin_role: updated.admin_role } : p)));
    } catch (err) {
      setError(err.message || 'تعذر إلغاء صلاحية المشرف');
    }
  };

  const handleUnblockUser = async (blockId) => {
    try {
      await unblockUser(blockId);
      setBlocks((prev) => prev.filter((b) => b.id !== blockId));
    } catch (err) {
      setError(err.message || 'تعذر إلغاء الحظر');
    }
  };

  const formatDate = (dateStr) =>
    new Date(dateStr).toLocaleDateString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric' });

  const formatDateTime = (dateStr) =>
    new Date(dateStr).toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

  const tabs = [
    { id: 'profiles', label: 'الملفات', icon: FileText },
    { id: 'messages', label: 'الرسائل', icon: MessageSquare },
    { id: 'users', label: 'المستخدمين', icon: Users },
    { id: 'issues', label: 'بلاغات الموقع', icon: Flag },
    { id: 'reports', label: 'بلاغات المستخدمين', icon: AlertCircle },
    { id: 'blocks', label: 'الحظر', icon: Ban },
    { id: 'audit', label: 'السجل', icon: ScrollText },
  ];

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="section-title mb-2">لوحة تحكم المشرف</h1>
        <p className="text-gray-600">إدارة المستخدمين والملفات والرسائل</p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: 'إجمالي المستخدمين', value: stats.totalUsers, icon: Users, color: 'bg-blue-50 text-blue-600' },
          { label: 'ملفات معتمدة', value: stats.approvedProfiles, icon: CheckCircle2, color: 'bg-green-50 text-green-600' },
          { label: 'ملفات معلقة', value: stats.pendingProfiles, icon: FileText, color: 'bg-amber-50 text-amber-600' },
          { label: 'رسائل معلقة', value: stats.pendingMessages, icon: MessageSquare, color: 'bg-rose-50 text-rose-600' },
          { label: 'بلاغات الموقع المفتوحة', value: stats.openIssues, icon: Flag, color: 'bg-red-50 text-red-600' },
          { label: 'بلاغات المستخدمين المفتوحة', value: stats.openReports, icon: AlertCircle, color: 'bg-red-50 text-red-600' },
        ].map((stat, idx) => (
          <div key={idx} className="card flex items-center gap-4">
            <div className={`flex h-12 w-12 items-center justify-center rounded-2xl ${stat.color}`}>
              <stat.icon size={24} />
            </div>
            <div>
              <p className="text-sm text-gray-500">{stat.label}</p>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="card">
        <div className="mb-6 flex gap-2 border-b border-gray-100 pb-4">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition-colors ${
                activeTab === tab.id ? 'bg-brand-600 text-white' : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
            >
              <tab.icon size={16} />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Profiles tab */}
        {activeTab === 'profiles' && (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[600px] text-sm">
              <thead>
                <tr className="border-b border-gray-100 text-right text-gray-500">
                  <th className="pb-3 font-medium">الاسم</th>
                  <th className="pb-3 font-medium">الجنس</th>
                  <th className="pb-3 font-medium">المدينة</th>
                  <th className="pb-3 font-medium">الحالة</th>
                  <th className="pb-3 font-medium">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {profiles.map((profile) => (
                  <tr key={profile.id} className="border-b border-gray-50 last:border-0">
                    <td className="py-3 font-semibold text-gray-900">{profile.الاسم}</td>
                    <td className="py-3 text-gray-600">{profile.الجنس === 'male' ? 'ذكر' : 'أنثى'}</td>
                    <td className="py-3 text-gray-600">{profile.المدينة}</td>
                    <td className="py-3">
                      {profile.is_approved ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2 py-1 text-xs font-semibold text-green-700">
                          <CheckCircle2 size={12} /> معتمد
                        </span>
                      ) : profile.account_status === 'pending' ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-1 text-xs font-semibold text-amber-700">
                          <ClockIcon size={12} /> معلق
                        </span>
                      ) : profile.account_status === 'hidden' ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-gray-100 px-2 py-1 text-xs font-semibold text-gray-700">
                          <EyeOff size={12} /> مخفي
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-2 py-1 text-xs font-semibold text-red-700">
                          <Ban size={12} /> موقوف
                        </span>
                      )}
                    </td>
                    <td className="py-3">
                      <div className="flex gap-2">
                        {profile.account_status === 'pending' && (
                          <button
                            onClick={() => handleApproveProfile(profile.id)}
                            className="rounded-lg bg-green-50 p-2 text-green-600 hover:bg-green-100"
                            title="اعتماد"
                          >
                            <CheckCircle2 size={16} />
                          </button>
                        )}
                        <button
                          onClick={() => handleSuspendProfile(profile.id)}
                          className="rounded-lg bg-red-50 p-2 text-red-600 hover:bg-red-100"
                          title="تعليق"
                        >
                          <Ban size={16} />
                        </button>
                        <button
                          onClick={() => navigate(`/admin/profiles/${profile.id}`)}
                          className="rounded-lg bg-brand-50 p-2 text-brand-600 hover:bg-brand-100"
                          title="عرض التفاصيل"
                        >
                          <Eye size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {loading && <div className="py-8 text-center text-sm text-gray-500">جاري التحميل...</div>}
        {error && <div className="rounded-2xl bg-red-50 p-4 text-sm text-red-700">{error}</div>}

        {/* Messages tab */}
        {activeTab === 'messages' && (
          <div className="space-y-4">
            {requests.length === 0 ? (
              <div className="rounded-2xl bg-gray-50 p-8 text-center text-sm text-gray-500">لا توجد طلبات تواصل</div>
            ) : (
              requests.map((msg) => (
                <div key={msg.id} className="rounded-2xl border border-gray-100 bg-white p-4">
                  <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                    <div className="text-sm">
                      <span className="font-bold text-gray-900">من:</span> {msg.senderName}{' '}
                      <span className="text-gray-400">←</span>{' '}
                      <span className="font-bold text-gray-900">إلى:</span> {msg.receiverName}
                    </div>
                    {msg.status === 'pending' ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-1 text-xs font-semibold text-amber-700">
                        <ClockIcon size={12} /> قيد المراجعة
                      </span>
                    ) : msg.status === 'approved' ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-1 text-xs font-semibold text-green-700">
                        <CheckCircle2 size={12} /> معتمدة
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-2.5 py-1 text-xs font-semibold text-red-700">
                        <XCircle size={12} /> مرفوضة
                      </span>
                    )}
                  </div>
                  <p className="mb-3 rounded-xl bg-gray-50 p-3 text-sm text-gray-700">{msg.content}</p>
                  {msg.status === 'pending' && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => onApproveMessage(msg.id)}
                        className="flex items-center gap-1 rounded-lg bg-green-50 px-3 py-1.5 text-xs font-semibold text-green-700 hover:bg-green-100"
                      >
                        <CheckCircle2 size={14} /> موافقة
                      </button>
                      <button
                        onClick={() => onRejectMessage(msg.id)}
                        className="flex items-center gap-1 rounded-lg bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-700 hover:bg-red-100"
                      >
                        <XCircle size={14} /> رفض
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {/* Users tab */}
        {activeTab === 'users' && (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[600px] text-sm">
              <thead>
                <tr className="border-b border-gray-100 text-right text-gray-500">
                  <th className="pb-3 font-medium">البريد</th>
                  <th className="pb-3 font-medium">الاسم</th>
                  <th className="pb-3 font-medium">الدور</th>
                  <th className="pb-3 font-medium">الحالة</th>
                  <th className="pb-3 font-medium">تاريخ التسجيل</th>
                  <th className="pb-3 font-medium">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {profiles.map((profile) => (
                  <tr key={profile.id} className="border-b border-gray-50 last:border-0">
                    <td className="py-3 font-semibold text-gray-900" dir="ltr">{profile.email || '-'}</td>
                    <td className="py-3 text-gray-600">{profile.الاسم}</td>
                    <td className="py-3 text-gray-600">{profile.is_admin ? `مشرف (${profile.admin_role || 'بدون دور'})` : 'مستخدم'}</td>
                    <td className="py-3">
                      {profile.account_status === 'active' ? (
                        <span className="rounded-full bg-green-100 px-2 py-1 text-xs font-semibold text-green-700">نشط</span>
                      ) : profile.account_status === 'suspended' ? (
                        <span className="rounded-full bg-red-100 px-2 py-1 text-xs font-semibold text-red-700">موقوف</span>
                      ) : (
                        <span className="rounded-full bg-amber-100 px-2 py-1 text-xs font-semibold text-amber-700">معلق</span>
                      )}
                    </td>
                    <td className="py-3 text-gray-500">{formatDate(profile.created_at)}</td>
                    <td className="py-3">
                      <div className="flex gap-2">
                        {!profile.is_admin ? (
                          <button
                            onClick={() => handleMakeAdmin(profile.user_id, 'moderator')}
                            className="rounded-lg bg-brand-50 p-2 text-brand-600 hover:bg-brand-100"
                            title="ترقية لمشرف"
                          >
                            <Shield size={16} />
                          </button>
                        ) : (
                          <button
                            onClick={() => handleRevokeAdmin(profile.user_id)}
                            className="rounded-lg bg-red-50 p-2 text-red-600 hover:bg-red-100"
                            title="إلغاء الصلاحية"
                          >
                            <Unlock size={16} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Issues tab */}
        {activeTab === 'issues' && (
          <div className="space-y-4">
            {issues.length === 0 ? (
              <div className="rounded-2xl bg-gray-50 p-8 text-center text-sm text-gray-500">لا توجد بلاغات</div>
            ) : (
              issues.map((issue) => (
                <div key={issue.id} className="rounded-2xl border border-gray-100 bg-white p-4">
                  <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                    <div className="text-sm">
                      <span className="font-bold text-gray-900">من:</span> {issue.reporter_name || issue.reporter_email}
                    </div>
                    {issue.status === 'open' ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-2.5 py-1 text-xs font-semibold text-red-700">
                        <AlertCircle size={12} /> مفتوح
                      </span>
                    ) : issue.status === 'in_progress' ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-1 text-xs font-semibold text-amber-700">
                        <ClockIcon size={12} /> قيد المعالجة
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-1 text-xs font-semibold text-green-700">
                        <CheckCircle2 size={12} /> مغلق
                      </span>
                    )}
                  </div>
                  <p className="mb-1 text-sm font-semibold text-gray-800">{issue.title}</p>
                  <p className="mb-3 rounded-xl bg-gray-50 p-3 text-sm text-gray-700">{issue.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {issue.status === 'open' && (
                      <button
                        onClick={() => handleReviewIssue(issue.id, 'in_progress')}
                        className="flex items-center gap-1 rounded-lg bg-amber-50 px-3 py-1.5 text-xs font-semibold text-amber-700 hover:bg-amber-100"
                      >
                        <ClockIcon size={14} /> قيد المعالجة
                      </button>
                    )}
                    {issue.status !== 'closed' && (
                      <button
                        onClick={() => handleReviewIssue(issue.id, 'closed')}
                        className="flex items-center gap-1 rounded-lg bg-green-50 px-3 py-1.5 text-xs font-semibold text-green-700 hover:bg-green-100"
                      >
                        <CheckCircle2 size={14} /> إغلاق
                      </button>
                    )}
                    {issue.status === 'closed' && (
                      <button
                        onClick={() => handleReviewIssue(issue.id, 'open')}
                        className="flex items-center gap-1 rounded-lg bg-gray-50 px-3 py-1.5 text-xs font-semibold text-gray-700 hover:bg-gray-100"
                      >
                        <Unlock size={14} /> إعادة فتح
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Reports tab */}
        {activeTab === 'reports' && (
          <div className="space-y-4">
            {reports.length === 0 ? (
              <div className="rounded-2xl bg-gray-50 p-8 text-center text-sm text-gray-500">لا توجد بلاغات بين المستخدمين</div>
            ) : (
              reports.map((report) => (
                <div key={report.id} className="rounded-2xl border border-red-100 bg-red-50/30 p-4">
                  <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                    <div className="text-sm">
                      <span className="font-bold text-gray-900">مبلّغ:</span>{' '}
                      {report.reporter_name || `${report.reporter_user_id?.slice(0, 8)}...`}{' '}
                      <span className="text-gray-400">←</span>{' '}
                      <span className="font-bold text-gray-900">مبلّغ عنه:</span>{' '}
                      {report.reported_name || `${report.reported_user_id?.slice(0, 8)}...`}
                    </div>
                    {report.status === 'open' ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-2.5 py-1 text-xs font-semibold text-red-700">
                        <AlertCircle size={12} /> مفتوح
                      </span>
                    ) : report.status === 'resolved' ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-1 text-xs font-semibold text-green-700">
                        <CheckCircle2 size={12} /> تم الحل
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded-full bg-gray-100 px-2.5 py-1 text-xs font-semibold text-gray-700">
                        <XCircle size={12} /> تم التجاهل
                      </span>
                    )}
                  </div>
                  <div className="mb-1 text-sm font-semibold text-gray-900">{report.reason}</div>
                  <p className="mb-3 text-sm text-gray-600">{report.details || 'لا توجد تفاصيل'}</p>
                  <div className="flex flex-wrap gap-2">
                    {report.status === 'open' && (
                      <button
                        onClick={() => handleReviewReport(report.id, 'resolved')}
                        className="flex items-center gap-1 rounded-lg bg-green-50 px-3 py-1.5 text-xs font-semibold text-green-700 hover:bg-green-100"
                      >
                        <CheckCircle2 size={14} /> تم الحل
                      </button>
                    )}
                    {report.status === 'open' && (
                      <button
                        onClick={() => handleReviewReport(report.id, 'dismissed')}
                        className="flex items-center gap-1 rounded-lg bg-gray-50 px-3 py-1.5 text-xs font-semibold text-gray-700 hover:bg-gray-100"
                      >
                        <XCircle size={14} /> تجاهل
                      </button>
                    )}
                    {report.status !== 'open' && (
                      <button
                        onClick={() => handleReviewReport(report.id, 'open')}
                        className="flex items-center gap-1 rounded-lg bg-amber-50 px-3 py-1.5 text-xs font-semibold text-amber-700 hover:bg-amber-100"
                      >
                        <Unlock size={14} /> إعادة فتح
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Blocks tab */}
        {activeTab === 'blocks' && (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[500px] text-sm">
              <thead>
                <tr className="border-b border-gray-100 text-right text-gray-500">
                  <th className="pb-3 font-medium">الحاسب المحظور</th>
                  <th className="pb-3 font-medium">المحظور من قبل</th>
                  <th className="pb-3 font-medium">السبب</th>
                  <th className="pb-3 font-medium">تاريخ الحظر</th>
                  <th className="pb-3 font-medium">إجراء</th>
                </tr>
              </thead>
              <tbody>
                {blocks.length === 0 ? (
                  <tr>
                    <td colSpan="5" className="py-8 text-center text-sm text-gray-500">لا توجد عمليات حظر</td>
                  </tr>
                ) : (
                  blocks.map((block) => (
                    <tr key={block.id} className="border-b border-gray-50 last:border-0">
                      <td className="py-3 text-gray-900">{block.blocked_name || block.blocked_email || '-'}</td>
                      <td className="py-3 text-gray-600">{block.blocker_name || block.blocker_email || '-'}</td>
                      <td className="py-3 text-gray-600">{block.reason || '-'}</td>
                      <td className="py-3 text-gray-500">{formatDate(block.created_at)}</td>
                      <td className="py-3">
                        <button
                          onClick={() => handleUnblockUser(block.id)}
                          className="rounded-lg bg-red-50 p-2 text-red-600 hover:bg-red-100"
                          title="إلغاء الحظر"
                        >
                          <Unlock size={16} />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Audit tab */}
        {activeTab === 'audit' && (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[500px] text-sm">
              <thead>
                <tr className="border-b border-gray-100 text-right text-gray-500">
                  <th className="pb-3 font-medium">المشرف</th>
                  <th className="pb-3 font-medium">الإجراء</th>
                  <th className="pb-3 font-medium">الهدف</th>
                  <th className="pb-3 font-medium">التفاصيل</th>
                  <th className="pb-3 font-medium">التاريخ</th>
                </tr>
              </thead>
              <tbody>
                {auditLogs.length === 0 ? (
                  <tr>
                    <td colSpan="5" className="py-8 text-center text-sm text-gray-500">لا توجد سجلات</td>
                  </tr>
                ) : (
                  auditLogs.map((log) => (
                    <tr key={log.id} className="border-b border-gray-50 last:border-0">
                      <td className="py-3 text-gray-900">{log.admin_name || log.admin_email || '-'}</td>
                      <td className="py-3 text-gray-600">{log.action}</td>
                      <td className="py-3 text-gray-600">{log.target_type} {log.target_id ? `#${log.target_id}` : ''}</td>
                      <td className="py-3 text-gray-600">{log.details || '-'}</td>
                      <td className="py-3 text-gray-500">{formatDateTime(log.created_at)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function ClockIcon({ size }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}