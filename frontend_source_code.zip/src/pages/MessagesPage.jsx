import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { MessageSquare, Send, Clock, CheckCircle2, XCircle, AlertCircle, ChevronLeft } from 'lucide-react';
import { fetchMyContactRequests, sendContactRequest } from '../services/contactRequestService';
import { fetchBlockedUserIds } from '../services/userBlockService';

export default function MessagesPage({ currentUser }) {
  const navigate = useNavigate();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [replyText, setReplyText] = useState('');
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [blockedIds, setBlockedIds] = useState([]);

  useEffect(() => {
    if (!currentUser?.id) return;
    async function loadRequests() {
      try {
        const [data, blocked] = await Promise.all([
          fetchMyContactRequests(),
          fetchBlockedUserIds().catch(() => []),
        ]);
        setRequests(data || []);
        setBlockedIds(blocked || []);
      } catch (err) {
        setError(err.message || 'تعذر تحميل الرسائل');
      } finally {
        setLoading(false);
      }
    }
    loadRequests();
  }, [currentUser?.id]);

  if (!currentUser) {
    return (
      <div className="mx-auto max-w-md py-16 text-center">
        <div className="card">
          <AlertCircle className="mx-auto mb-4 h-12 w-12 text-amber-500" />
          <h2 className="mb-3 text-xl font-bold text-gray-900">يجب تسجيل الدخول</h2>
          <button onClick={() => navigate('/login')} className="btn-primary w-full">
            تسجيل الدخول
          </button>
        </div>
      </div>
    );
  }

  const approvedReceived = requests.filter(
    (r) =>
      r.receiver_user_id === currentUser.id &&
      r.status === 'approved' &&
      !blockedIds.includes(r.sender_user_id)
  );

  const sentRequests = requests.filter(
    (r) => r.sender_user_id === currentUser.id && !blockedIds.includes(r.receiver_user_id)
  );

  const handleReply = async (e) => {
    e.preventDefault();
    if (!replyText.trim() || !selectedRequest) return;

    try {
      await sendContactRequest({
        receiver_user_id: selectedRequest.sender_user_id,
        message: replyText.trim(),
      });
      const data = await fetchMyContactRequests();
      setRequests(data || []);
      setReplyText('');
      setSelectedRequest(null);
    } catch (err) {
      setError(err.message || 'تعذر إرسال الرد');
    }
  };

  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-1 text-xs font-semibold text-green-700">
            <CheckCircle2 size={12} />
            تمت الموافقة
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-2.5 py-1 text-xs font-semibold text-red-700">
            <XCircle size={12} />
            مرفوضة
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-1 text-xs font-semibold text-amber-700">
            <Clock size={12} />
            قيد المراجعة
          </span>
        );
    }
  };

  return (
    <div className="mx-auto max-w-4xl py-6">
      <div className="mb-6 text-center">
        <h1 className="section-title mb-2">الرسائل</h1>
        <p className="text-gray-600">رسائلك المرسلة والواردة بعد مراجعة المشرف</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Received requests */}
        <div className="card">
          <div className="mb-4 flex items-center gap-2">
            <MessageSquare size={20} className="text-brand-600" />
            <h2 className="text-lg font-bold text-gray-900">طلبات التواصل الواردة المعتمدة</h2>
          </div>

          {loading ? (
            <div className="py-8 text-center text-sm text-gray-500">جاري التحميل...</div>
          ) : approvedReceived.length === 0 ? (
            <div className="rounded-2xl bg-gray-50 p-6 text-center text-sm text-gray-500">
              لا توجد طلبات واردة معتمدة بعد
            </div>
          ) : (
            <div className="space-y-3">
              {approvedReceived.map((req) => (
                <div
                  key={req.id}
                  onClick={() => setSelectedRequest(req)}
                  className={`cursor-pointer rounded-2xl border p-4 transition-all hover:shadow-soft ${
                    selectedRequest?.id === req.id ? 'border-brand-500 bg-brand-50/50' : 'border-gray-100 bg-white'
                  }`}
                >
                  <div className="mb-2 flex items-center justify-between">
                    <span className="font-bold text-gray-900">{req.sender_name || 'مستخدم'}</span>
                    {getStatusBadge(req.status)}
                  </div>
                  <p className="mb-2 text-sm text-gray-700 line-clamp-2">{req.message}</p>
                  <span className="text-xs text-gray-400">{formatDate(req.reviewed_at || req.created_at)}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Sent requests */}
        <div className="card">
          <div className="mb-4 flex items-center gap-2">
            <Send size={20} className="text-brand-600" />
            <h2 className="text-lg font-bold text-gray-900">طلبات التواصل المرسلة</h2>
          </div>

          {loading ? (
            <div className="py-8 text-center text-sm text-gray-500">جاري التحميل...</div>
          ) : sentRequests.length === 0 ? (
            <div className="rounded-2xl bg-gray-50 p-6 text-center text-sm text-gray-500">
              لم ترسل أي طلبات بعد
            </div>
          ) : (
            <div className="space-y-3">
              {sentRequests.map((req) => (
                <div key={req.id} className="rounded-2xl border border-gray-100 bg-white p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <span className="font-bold text-gray-900">إلى: {req.receiver_name || 'مستخدم'}</span>
                    {getStatusBadge(req.status)}
                  </div>
                  <p className="mb-2 text-sm text-gray-700 line-clamp-2">{req.message}</p>
                  <span className="text-xs text-gray-400">{formatDate(req.created_at)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Reply form */}
      {selectedRequest && (
        <div className="mt-6 card">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-base font-bold text-gray-900">الرد على {selectedRequest.sender_name || 'مستخدم'}</h3>
            <button onClick={() => setSelectedRequest(null)} className="text-xs text-gray-500 hover:text-gray-700">
              إغلاق
            </button>
          </div>
          <form onSubmit={handleReply} className="space-y-3">
            <textarea
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              className="input-field min-h-[100px] resize-none"
              placeholder="اكتب ردك..."
              required
            />
            <button type="submit" className="btn-primary w-full" disabled={!replyText.trim()}>
              <Send size={16} />
              إرسال الرد للمراجعة
            </button>
          </form>
        </div>
      )}
    </div>
  );
}