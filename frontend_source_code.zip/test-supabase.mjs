import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  'https://zftdssfqavdlsnulpheq.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpmdGRzc2ZxYXZkbHNudWxwaGVxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY1NTg3ODEsImV4cCI6MjEwMjEzNDc4MX0.gWGBT50I7WlI4iqm6k_LDn3-bHhL-YzkLwTxCvzmNuc'
);

const testEmail = `test_brmej_${Date.now()}@example.com`;
const testPassword = 'TestPass123!';

async function test() {
  console.log('--- Testing Supabase connection ---');

  // 1. Sign up
  console.log('\n1. Sign up test user:', testEmail);
  const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
    email: testEmail,
    password: testPassword,
  });

  if (signUpError) {
    console.error('Sign up error:', signUpError);
    return;
  }
  console.log('Sign up success. User ID:', signUpData.user?.id);
  console.log('Session exists after sign up:', !!signUpData.session);

  if (!signUpData.session) {
    console.log('\n--- Email confirmation required ---');
    console.log('Sign up succeeded, but email confirmation is required before login.');
    console.log('This matches the UI behavior: user sees "confirmation email sent" message.');
    console.log('Cannot proceed to profile/partner_preferences/contact_request tests without confirming email.');
    return;
  }

  // 2. Sign in (only if session was created, meaning email confirmation is disabled)
  console.log('\n2. Sign in test user');
  const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
    email: testEmail,
    password: testPassword,
  });

  if (signInError) {
    console.error('Sign in error:', signInError);
    return;
  }
  console.log('Sign in success. User ID:', signInData.user?.id);

  const userId = signInData.user.id;

  // 3. Create profile
  console.log('\n3. Create profile');
  const { data: profileData, error: profileError } = await supabase
    .from('profiles')
    .insert({
      user_id: userId,
      الاسم: 'مستخدم تجريبي',
      العمر: 30,
      الجنس: 'ذكر',
      المدينة: 'المكلا',
      الحالة_الاجتماعية: 'أعزب',
      المؤهل_الدراسي: 'جامعي',
      الوظيفة: 'مهندس',
      الطول: 175,
      لون_البشرة: 'أبيض',
      قبلي_او_حضري: 'حضري',
      الحالة_الصحية: 'سليم',
      الحالة_المادية: 'متوسط',
      نبذة_عن_نفسه: 'ملف تجريبي للاختبار',
      إقرار_الزواج: true,
      account_status: 'active',
    })
    .select()
    .single();

  if (profileError) {
    console.error('Create profile error:', profileError);
    return;
  }
  console.log('Create profile success. Profile ID:', profileData.id);

  const profileId = profileData.id;

  // 4. Fetch profile by user_id
  console.log('\n4. Fetch profile by user_id');
  const { data: fetchedProfile, error: fetchProfileError } = await supabase
    .from('profiles')
    .select('*')
    .eq('user_id', userId)
    .single();

  if (fetchProfileError) {
    console.error('Fetch profile error:', fetchProfileError);
    return;
  }
  console.log('Fetch profile success:', fetchedProfile.الاسم);

  // 5. Create partner_preferences
  console.log('\n5. Create partner_preferences');
  const { data: prefData, error: prefError } = await supabase
    .from('partner_preferences')
    .insert({
      profile_id: profileId,
      preferred_gender: 'أنثى',
      min_age: 20,
      max_age: 35,
      preferred_city: 'المكلا',
      preferred_education: 'جامعي',
      preferred_skin: 'أبيض',
      preferred_tribal: 'حضري',
      notes: 'مواصفات تجريبية',
    })
    .select()
    .single();

  if (prefError) {
    console.error('Create partner_preferences error:', prefError);
    return;
  }
  console.log('Create partner_preferences success. ID:', prefData.id);

  // 6. Fetch partner_preferences
  console.log('\n6. Fetch partner_preferences');
  const { data: fetchedPref, error: fetchPrefError } = await supabase
    .from('partner_preferences')
    .select('*')
    .eq('profile_id', profileId)
    .single();

  if (fetchPrefError) {
    console.error('Fetch partner_preferences error:', fetchPrefError);
    return;
  }
  console.log('Fetch partner_preferences success:', fetchedPref.preferred_city);

  // 7. Create contact_request
  console.log('\n7. Create contact_request (to self for testing)');
  const { data: contactData, error: contactError } = await supabase
    .from('contact_requests')
    .insert({
      sender_user_id: userId,
      receiver_user_id: userId,
      message: 'رسالة تجريبية للاختبار',
      status: 'pending',
      request_type: 'message',
    })
    .select()
    .single();

  if (contactError) {
    console.error('Create contact_request error:', contactError);
    return;
  }
  console.log('Create contact_request success. ID:', contactData.id);

  // 8. Fetch contact_requests
  console.log('\n8. Fetch my contact_requests');
  const { data: fetchedContacts, error: fetchContactsError } = await supabase
    .from('contact_requests')
    .select('*')
    .or(`sender_user_id.eq.${userId},receiver_user_id.eq.${userId}`);

  if (fetchContactsError) {
    console.error('Fetch contact_requests error:', fetchContactsError);
    return;
  }
  console.log('Fetch contact_requests success. Count:', fetchedContacts.length);

  console.log('\n--- All tests passed ---');
}

test().catch(console.error);
