import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  base: '/sandbox/363/front/',
  server: { allowedHosts: true, hmr: { protocol: 'wss', clientPort: 443 } },
})
